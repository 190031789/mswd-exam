export interface Currency {
  currency: string;
  weight?: number;
  rate?: number;
}

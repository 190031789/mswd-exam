export interface ExchangeRates {
  [property: string]: number;
}

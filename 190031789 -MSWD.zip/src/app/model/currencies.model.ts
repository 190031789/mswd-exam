import { Currency } from './currency.model';

export interface Currencies {
  [property: string]: Currency;
}
